# Kart Simulation Subsystem

## Usage

## Project architecture

The project is moving to a monorepo for the autonomous Top Kart Dreamer. The
finalized target structure is documented below; executable ROS/Docker/MuJoCo
integration has not been implemented yet.

- [Architecture and directory ownership](docs/architecture.md)
- [ROS packages, topics, frames, and launch structure](docs/ros-structure.md)
- [Docker images and deployment modes](docs/docker-deployment.md)
- [Hardware inventory](docs/hardware.md)
- [Decisions, version candidates, and open questions](docs/decisions.md)

The older `handoff/kart-bringup/` material is superseded by the monorepo design.
